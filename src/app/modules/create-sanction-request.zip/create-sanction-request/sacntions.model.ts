

export class Sanctions {

    public Activitytype : string=null;
    
    public Policytype:string=null;

    public Policyno: number=null;

    public Policydate:Date=null;

    public Claimdate: Date=null;

    public Claimdatils=null;
}