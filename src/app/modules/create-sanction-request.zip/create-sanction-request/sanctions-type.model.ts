
export class SanctionsType {
    public SanctionsType: string;
}


